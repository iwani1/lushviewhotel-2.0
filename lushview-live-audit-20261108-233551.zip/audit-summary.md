# Lush View Hotel — Live System & Operations Audit

- **Generated (UTC):** 2026-11-08T23:35:50Z
- **Collection Time:** 299 ms (read-only; zero DB/file writes)
- **Privacy Mode:** Strict — zero credentials, keys, guest PII, or employee PII exported

## 0. Post-1.8.0 Live Health Scorecard (12/14 PASS, 2 WARN, 0 FAIL)

| Status | Check | Detail |
|:---:|---|---|
| **PASS** | QloApps Runtime Code Version (_QLOAPPS_VERSION_) | Active constant: 1.8.0.0 |
| **PASS** | QloApps Database Schema Version (QLO_VERSION_DB) | Active DB value: 1.8.0.0 |
| **PASS** | PHP 8.2–8.5 Runtime & Required Extensions | PHP 8.4.27 (all 9 extensions loaded) |
| **PASS** | All 27 New QloApps 1.8.0 Tables Present | 27 / 27 present |
| **PASS** | All 23 New QloApps 1.8.0 Columns Present | 23 / 23 present |
| **PASS** | Bcrypt Password (varchar>=60) & Payment Amount (decimal 20,6) | employee/customer/referrer passwd varchar(60)+ & order_payment* decimal(20,6) verified |
| **PASS** | 1.8.0 Signature Classes, Crypto Library & Ghana Pack (gh.xml) | All 6 signature 1.8.0 & localization files verified on disk |
| **PASS** | Back-Office Reflected XSS Fix (search_form.tpl) | {$bo_query/escape:'html':'UTF-8'} verified in live admin template |
| **WARN** | Installer, CHANGELOG & Staging Directory Cleanup | Leftover paths present: CHANGELOG.txt |
| **PASS** | CVE-2025-67325 Watch (qlohotelreview) & Orphan Modules | qlohotelreview=disabled, DB-only orphan modules=0 |
| **PASS** | Hotel Amenities & Homepage Hero Media (htl_header_image) | 42 amenities (7 hotel links, 0 room-type links); 1 hero image row(s) (all files on disk) |
| **WARN** | Bookings, Guests, Payments & Room Relational Integrity | 1955 bookings, 1270 guests, 2083 payments, 38 physical rooms; orphan booking_detail=24, orphan room_type=0 |
| **PASS** | Active Upstream Module Version Parity (DB vs Disk) | All active upstream modules match their 1.8.0 disk version |
| **PASS** | Public Hotel Storefront, HTTPS & Production Debug Mode | Storefront=LIVE (open to guests), SSL Everywhere=ON, _PS_MODE_DEV_=OFF |

## 1. Runtime & 1.8.0 Readiness
- **QloApps Code / DB Version:** `1.8.0.0` / `1.8.0.0`
- **PHP Runtime:** `8.4.27` (`litespeed`, memory `512M`, max_execution_time `600`)
- **Database Server:** `11.4.13-MariaDB` (`328` tables, `27.64 MB`)
- **Missing 1.8.0 PHP Extensions:** None (all present)

## 2. Code Integrity & Modules
- **Baseline Compared:** `v1.8.0`
- **Modified Upstream Files:** `0`
- **Active `override/` Files:** `0`
- **Active Modules in DB:** `56`
- **Custom / Non-Standard Modules:** blockcms, blockcontact, blockcontactinfos, blockfacebook, blocklayered, blockmanufacturer, blockpaymentlogo, blockspecials, blocktags, blockviewed, blockwishlist, cronjobs, emailgenerator, feeder, ganalytics, gapi, gsitemap, mailalerts, producttooltip, socialsharing, statsbestsuppliers, statscarrier
- **DB-Only Orphan Modules:** `0`
- **`qlohotelreview` Status (CVE-2025-67325 watch):** Disabled / Not active

## 3. Hotel Catalog & Room Inventory
- **Room Types:** `8`
- **Physical Rooms:** `38`

| ID | Room Type | Base Price | Active | Max Guests | Images |
|---:|---|---:|:---:|---:|---:|
| 2 | Double Standard Rooms | 600 | Yes | 4 | 3 |
| 3 | Executive Rooms | 700 | Yes | 4 | 4 |
| 4 | Suites Rooms | 900 | Yes | 4 | 4 |
| 13 | Standard Room | 500 | Yes | 4 | 4 |
| 18 | Conference Rooms 24 hours | 3000 | Yes | 60 | 1 |
| 22 | Conference Rooms  3 hours | 1600 | Yes | 60 | 1 |
| 23 | Conference Rooms - 2 Hours | 1300 | Yes | 60 | 1 |
| 24 | Conference Rooms - 1 Hour | 1000 | Yes | 60 | 1 |

## 4. Operations & Payment Workflows (Aggregated)
- **Total Orders Recorded:** `1955`

### Payment Modules Used
| Module | Label | Currency | Orders | Total Invoiced | Total Paid Real |
|---|---|---|---:|---:|---:|
| `bo_order` | Cash Payment | GHS | 880 | 602700.00 | 604900.00 |
| `bo_order` | momo | GHS | 738 | 519600.00 | 519650.00 |
| `bo_order` | awaiting payment | GHS | 237 | 540250.00 | 478662.00 |
| `bo_order` | P.O.S | GHS | 42 | 29600.00 | 29600.00 |
| `bo_order` | POS | GHS | 22 | 17600.00 | 17600.00 |
| `bo_order` | Momo payment | GHS | 12 | 6700.00 | 6700.00 |
| `free_order` | Free order | GHS | 8 | 0.00 | 0.00 |
| `bo_order` | Cash | GHS | 5 | 3200.00 | 3200.00 |
| `bankwire` | Bank wire | GHS | 3 | 3600.00 | 3600.00 |
| `bo_order` | partial payment | GHS | 2 | 1500.00 | 1500.00 |
| `bo_order` | P O S | GHS | 1 | 700.00 | 700.00 |
| `bo_order` | P. O. S | GHS | 1 | 1400.00 | 1400.00 |
| `bo_order` | mom | GHS | 1 | 500.00 | 500.00 |
| `bo_order` | Cash Payment and Momo | GHS | 1 | 500.00 | 500.00 |
| `bo_order` | 84265253757 | GHS | 1 | 500.00 | 500.00 |
| `bo_order` | Bank wire | GHS | 1 | 500.00 | 500.00 |

## 5. Bundled Custom / Modified Files in Archive
- **Files Included:** `57`
  - `custom-files/modules/blockcms/translations/en.php`
  - `custom-files/modules/blockcontact/translations/en.php`
  - `custom-files/modules/blockcontactinfos/translations/en.php`
  - `custom-files/modules/blockfacebook/translations/en.php`
  - `custom-files/modules/blocklayered/translations/en.php`
  - `custom-files/modules/blockmanufacturer/translations/en.php`
  - `custom-files/modules/blockpaymentlogo/translations/en.php`
  - `custom-files/modules/blockspecials/translations/en.php`
  - `custom-files/modules/blocktags/translations/en.php`
  - `custom-files/modules/blockviewed/translations/en.php`
  - `custom-files/modules/blockwishlist/mails/en/wishlist.txt`
  - `custom-files/modules/blockwishlist/mails/en/wishlink.html`
  - `custom-files/modules/blockwishlist/mails/en/wishlist.html`
  - `custom-files/modules/blockwishlist/mails/en/wishlink.txt`
  - `custom-files/modules/blockwishlist/translations/en.php`
  - `custom-files/modules/cronjobs/translations/en.php`
  - `custom-files/modules/emailgenerator/templates_translations/en/lang_content.php`
  - `custom-files/modules/feeder/translations/en.php`
  - `custom-files/modules/ganalytics/translations/en.php`
  - `custom-files/modules/gapi/translations/en.php`
  - `custom-files/modules/gsitemap/translations/en.php`
  - `custom-files/modules/mailalerts/mails/en/order_changed.txt`
  - `custom-files/modules/mailalerts/mails/en/return_slip.html`
  - `custom-files/modules/mailalerts/mails/en/customer_qty.html`
  - `custom-files/modules/mailalerts/mails/en/return_slip.txt`
  - `custom-files/modules/mailalerts/mails/en/productoutofstock.txt`
  - `custom-files/modules/mailalerts/mails/en/productcoverage.html`
  - `custom-files/modules/mailalerts/mails/en/productcoverage.txt`
  - `custom-files/modules/mailalerts/mails/en/new_order.html`
  - `custom-files/modules/mailalerts/mails/en/customer_qty.txt`
  - `custom-files/modules/mailalerts/mails/en/productoutofstock.html`
  - `custom-files/modules/mailalerts/mails/en/order_changed.html`
  - `custom-files/modules/mailalerts/mails/en/new_order.txt`
  - `custom-files/modules/mailalerts/translations/en.php`
  - `custom-files/modules/producttooltip/translations/en.php`
  - `custom-files/modules/socialsharing/translations/en.php`
  - `custom-files/modules/statsbestsuppliers/translations/en.php`
  - `custom-files/modules/statscarrier/translations/en.php`
  - `custom-files/modified-or-added/pdf/invoice.extra-demands-tab.tpl`
  - `custom-files/modified-or-added/themes/hotel-reservation-theme/_partials/cart_booking_demands.tpl`
  - `custom-files/modified-or-added/mails/en/bankwire.html`
  - `custom-files/modified-or-added/mails/en/cheque.html`
  - `custom-files/modified-or-added/mails/en/payment.html`
  - `custom-files/modified-or-added/mails/en/outofstock.html`
  - `custom-files/modified-or-added/mails/en/booking_extra_demands_text.tpl`
  - `custom-files/modified-or-added/mails/en/preparation.html`
  - `custom-files/modified-or-added/mails/en/booking_extra_demands.tpl`
  - `custom-files/modified-or-added/modules/qlohotelreview/controllers/admin/AdminParentHotelReview.php`
  - `custom-files/modified-or-added/modules/qlohotelreview/controllers/admin/AdminHotelReviewCategory.php`
  - `custom-files/modified-or-added/modules/qlohotelreview/controllers/admin/AdminHotelReviewHotelReview.php`
  - `custom-files/modified-or-added/modules/dashguestcycle/views/templates/hook/dashboard-top.tpl`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/templates/admin/hotel_features/helpers/form/form.tpl`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/templates/admin/hotel_features/helpers/view/view.tpl`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/templates/admin/room_type_global_demand/_partials/price_calc_method_badge.tpl`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/templates/admin/room_type_global_demand/helpers/form/form.tpl`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/js/hotelImage.js`
  - `custom-files/modified-or-added/modules/hotelreservationsystem/views/css/HotelReservationFront.css`
